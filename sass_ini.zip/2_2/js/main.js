window.addEventListener("load", function(){
    console.log("Web cargada");
})
